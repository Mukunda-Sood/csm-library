# Solution Capability Usage Table — Format Reference

This document describes the expected format for the
`Solution Capability Usage Table.xlsx` uploaded by the user.

---

## Recommended: Use the Template

The simplest approach is to download `assets/Solution_Capability_Usage_Template.xlsx`,
which contains 26 pre-filled rows matching the reference Cloud ERP slide. Edit the rows
to reflect the customer's actual solution usage.

---

## Required Columns

The script auto-detects column names (case-insensitive). Use these exact names
or close variants.

| Column | Required | Description | Auto-detected aliases |
|--------|----------|-------------|----------------------|
| **Group** | ✓ | Column ID: `G1`, `G2`, `G3`, `G4` | `Group ID`, `Col`, `Column` |
| **Feature ID** | ✓ | SAP AI feature identifier (e.g. `J74`) | `Identifier`, `ID`, `Feature_ID` |
| **Solution Capability** | ✓ | Capability label shown under the feature on the slide | `Capability`, `SC Name`, `SC` |
| **Status** | ✓ | `Active` or `Inactive` | `Usage Status`, `Adoption Status`, `Active` |
| **Group Title** | recommended | Column heading (e.g. `Faster Close & Automation`) | `Area`, `Process Area`, `Title` |
| **KPI** | recommended | KPI line under heading (e.g. `KPI: Close time, cost/transaction`) | `KPI Text`, `KPI Line` |
| **Feature Name** | optional | Short display name override. If blank, uses full name from CSV. | `Name`, `Display Name` |

---

## Example Layout

```
| Group | Group Title                | KPI                              | Feature ID | Solution Capability       | Status   | Feature Name                |
|-------|----------------------------|----------------------------------|------------|---------------------------|----------|-----------------------------|
| G1    | Faster Close & Automation  | KPI: Close time, cost/transaction| J74        | All active capabilities   | Active   | Joule for S/4HANA Cloud     |
| G1    | Faster Close & Automation  | KPI: Close time, cost/transaction| J336       | Overhead Cost Management  | Active   | Error Resolution for Cost Acctg |
| G1    | Faster Close & Automation  | KPI: Close time, cost/transaction| J375       | Payments & Bank Comm.     | Inactive | Payment Exception Analysis  |
| G2    | Financial Reporting        | KPI: Forecast accuracy           | J88        | Real-Time Reporting       | Active   | Analytical Business Insights|
```

---

## Finding Feature IDs

Open `data/AI Features Data.csv` and search by feature name. Copy the **Identifier**
column value (e.g. `J74`, `J88`, `J1104`).

Common S/4HANA Cloud Public Edition features:

| Feature Name (display) | Feature ID | Badge |
|------------------------|------------|-------|
| Joule for S/4HANA Cloud | J74 | Base |
| Error Resolution for Cost Acctg | J336 | Base |
| Posting Issue: Billing Docs | J355 | Base |
| Payment Advices (Document AI) | J1104 | Premium |
| Payment Exception Analysis | J375 | Beta |
| PO Approvals Reminder | J1310 | Base |
| Supplier Confirmation Mass Create | J1114 | Base |
| Supplier Delivery Date Update | J757 | Base |
| Analytical Business Insights | J88 | Premium |
| Compliance Info Processing | J345 | Beta |
| Config for US Tax Jurisdictions | J89 | Premium |
| Fixed Asset Depreciation Keys | J86 | Premium |
| Fixed Asset Key Figures | J288 | Premium |
| Note Corrections: Project Billing | J346 | Premium |
| Smart Home Personalization | J226 | Premium |
| Smart Solution for Situations | J181 | Beta |
| Creation of Fixed Asset Master | J298 | Base |
| Expiring Price Handling | J313 | Base |
| Easy Fill | J281 | Beta |
| Easy Filter | J91 | Base |
| Enterprise Search | J225 | Base |
| Smart Summarization | J90 | Base |
| Form Extension (Localization) | J117 | Premium |
| Quality Certs (Document AI) | J358 | Premium |
| Error Explanation | J227 | Premium |
| ABAP AI (Joule for Dev) | J792 | Premium |

---

## Status Values

| Value | Meaning | Dot Color |
|-------|---------|-----------|
| `Active` | Customer actively uses this capability | Green |
| `Inactive` | Capability exists but not yet used | Blue |

Numeric values also accepted: `> 0` = Active, `0` = Inactive.

---

## Sheet Names

The script reads the sheet named **`Capabilities`** first, then falls back to the first sheet.
The template's second sheet (`Instructions`) is ignored.

---

## Constraints

- Maximum **4 groups** (G1–G4) per slide
- Maximum **~9 features per column** before overflow
- Feature IDs not found in `data/AI Features Data.csv` will use the raw Feature ID as name
  with a "Base" badge (add a `Feature Name` column to override)
