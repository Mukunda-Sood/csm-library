#!/usr/bin/env python3
"""
process_data.py — AI Adoption Potential Skill
Reads AI Features Data.csv + customer xlsx → outputs slide_data.json

Usage:
  python scripts/process_data.py
    --csv  "data/AI Features Data.csv"
    --xlsx <path-to-Solution_Capability_Usage_Table.xlsx>
    --customer "PPGF"
    --scope "Cloud ERP"
    --output /tmp/sandbox/work/slide_data.json
"""

import argparse
import json
import sys
from pathlib import Path

try:
    import pandas as pd
except ImportError:
    print("ERROR: pandas not installed. Run: pip install pandas openpyxl")
    sys.exit(1)


# ── Column detection ──────────────────────────────────────────────────────────

def _find_col(df_cols, candidates):
    """Return first matching column name (case-insensitive)."""
    lower = {c.lower().strip(): c for c in df_cols}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    return None


# ── Load AI Features CSV ──────────────────────────────────────────────────────

def load_ai_features(csv_path: str) -> dict:
    """Returns dict keyed by Identifier (e.g. 'J74')."""
    df = pd.read_csv(csv_path)
    df.columns = df.columns.str.strip()
    features = {}
    for _, row in df.iterrows():
        ident = str(row.get("Identifier", "")).strip()
        if not ident or ident == "nan":
            continue
        quick_filters = str(row.get("Quick Filters", "")).lower()
        commercial    = str(row.get("Commercial Type", "")).strip()
        availability  = str(row.get("Availability", "")).strip()
        # Determine badge type
        if "beta" in availability.lower():
            badge = "Beta"
        elif commercial.lower() == "premium":
            badge = "Premium"
        else:
            badge = "Base"
        features[ident] = {
            "name":        str(row.get("Name", ident)).strip(),
            "product":     str(row.get("Product", "")).strip(),
            "description": str(row.get("Description", "")).strip(),
            "badge":       badge,
            "is_joule":    "joule" in quick_filters,
            "availability": availability,
        }
    return features


# ── Load xlsx ────────────────────────────────────────────────────────────────

def load_xlsx(xlsx_path: str):
    """
    Returns list of row dicts. Tries sheet named 'Capabilities' first,
    then the first sheet.
    """
    xl = pd.ExcelFile(xlsx_path, engine="openpyxl")
    sheet_name = "Capabilities" if "Capabilities" in xl.sheet_names else xl.sheet_names[0]
    df = xl.parse(sheet_name)
    df.columns = df.columns.str.strip()
    df = df.dropna(how="all")

    # Detect columns
    group_col  = _find_col(df.columns, ["Group", "Group ID", "Col", "Column"])
    title_col  = _find_col(df.columns, ["Group Title", "Area", "Process Area", "Title"])
    kpi_col    = _find_col(df.columns, ["KPI", "KPI Text", "KPI Line"])
    id_col     = _find_col(df.columns, ["Feature ID", "Identifier", "ID", "Feature_ID"])
    cap_col    = _find_col(df.columns, ["Solution Capability", "Capability", "SC Name", "SC"])
    status_col = _find_col(df.columns, ["Status", "Usage Status", "Active", "Adoption Status"])
    name_col   = _find_col(df.columns, ["Feature Name", "Name", "Display Name"])

    missing = []
    if not group_col:  missing.append("Group")
    if not id_col:     missing.append("Feature ID")
    if not cap_col:    missing.append("Solution Capability")
    if not status_col: missing.append("Status")
    if missing:
        raise ValueError(
            f"Required columns not found in xlsx: {', '.join(missing)}.\n"
            f"Found columns: {list(df.columns)}\n"
            f"See references/xlsx_format.md for expected format."
        )

    rows = []
    for _, row in df.iterrows():
        group_id = str(row.get(group_col, "")).strip()
        if not group_id or group_id == "nan":
            continue
        feat_id = str(row.get(id_col, "")).strip()
        if not feat_id or feat_id == "nan":
            continue

        status_raw = str(row.get(status_col, "")).strip().lower()
        if status_raw in ("active", "yes", "true", "1"):
            status = "Active"
        elif status_raw in ("inactive", "not active", "no", "false", "0"):
            status = "Inactive"
        else:
            # Try numeric
            try:
                status = "Active" if float(status_raw) > 0 else "Inactive"
            except (ValueError, TypeError):
                status = "Inactive"

        rows.append({
            "group_id":   group_id,
            "group_title": str(row.get(title_col, "")) if title_col else "",
            "kpi":        str(row.get(kpi_col, ""))  if kpi_col  else "",
            "feature_id": feat_id,
            "capability": str(row.get(cap_col, "")).strip(),
            "status":     status,
            "name_override": str(row.get(name_col, "")).strip() if name_col else "",
        })
    return rows


# ── Build slide data ──────────────────────────────────────────────────────────

def build_slide_data(ai_features: dict, xlsx_rows: list,
                     customer: str, scope: str) -> dict:
    # Group rows
    groups_map = {}
    for row in xlsx_rows:
        gid = row["group_id"]
        if gid not in groups_map:
            groups_map[gid] = {
                "id":    gid,
                "title": row["group_title"],
                "kpi":   row["kpi"],
                "features": [],
            }
        feat_id  = row["feature_id"]
        feat_csv = ai_features.get(feat_id, {})
        # Resolve name
        name = (row["name_override"]
                if row["name_override"] and row["name_override"] != "nan"
                else feat_csv.get("name", feat_id))
        # Capability
        capability = row["capability"] if row["capability"] and row["capability"] != "nan" else ""
        # Badge & joule from CSV (can be overridden if needed)
        badge    = feat_csv.get("badge", "Base")
        is_joule = feat_csv.get("is_joule", False)

        groups_map[gid]["features"].append({
            "name":       name,
            "capability": capability,
            "status":     row["status"],
            "badge":      badge,
            "is_joule":   is_joule,
            "feature_id": feat_id,
        })

    # Sort groups by ID (G1, G2, G3, G4)
    groups = sorted(groups_map.values(), key=lambda g: g["id"])

    # Compute stats
    all_features = [f for g in groups for f in g["features"]]
    total        = len(all_features)
    active       = sum(1 for f in all_features if f["status"] == "Active")
    inactive     = total - active
    base         = sum(1 for f in all_features if f["badge"] == "Base")
    premium      = sum(1 for f in all_features if f["badge"] == "Premium")
    joule_count  = sum(1 for f in all_features if f["is_joule"])

    return {
        "title":    f"AI Adoption Potential — {scope}",
        "subtitle": (f"Mapped to {customer} active and target solution capabilities  ·  "
                     f"Source: SAP AI Feature Catalog + {customer} L6M Usage Analytics"),
        "groups": groups,
        "stats": {
            "total":                    total,
            "immediately_actionable":   active,
            "expansion_opportunities":  inactive,
            "base_included":            base,
            "premium_required":         premium,
            "joule_enabled":            joule_count,
        },
    }


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Process AI Adoption data → slide_data.json")
    parser.add_argument("--csv",      required=True, help="Path to AI Features Data.csv")
    parser.add_argument("--xlsx",     required=True, help="Path to Solution Capability Usage Table.xlsx")
    parser.add_argument("--customer", default="Customer", help="Customer name for subtitle")
    parser.add_argument("--scope",    default="Cloud ERP", help="Scope/title suffix")
    parser.add_argument("--output",   required=True, help="Output JSON path")
    args = parser.parse_args()

    print(f"Loading AI features from: {args.csv}")
    ai_features = load_ai_features(args.csv)
    print(f"  → {len(ai_features)} features loaded")

    print(f"Loading capability usage from: {args.xlsx}")
    xlsx_rows = load_xlsx(args.xlsx)
    n_groups  = len({r["group_id"] for r in xlsx_rows})
    print(f"  → {len(xlsx_rows)} rows loaded")
    print(f"  → {len(xlsx_rows)} features across {n_groups} groups")

    slide_data = build_slide_data(ai_features, xlsx_rows, args.customer, args.scope)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(slide_data, f, indent=2, ensure_ascii=False)
    print(f"Slide data written to: {args.output}")


if __name__ == "__main__":
    main()
