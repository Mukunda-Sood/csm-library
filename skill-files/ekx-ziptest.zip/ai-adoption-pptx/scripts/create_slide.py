#!/usr/bin/env python3
"""
create_slide.py — AI Adoption Potential Skill
Reads slide_data.json → generates pixel-accurate PPTX slide.

Usage:
  python scripts/create_slide.py  slide_data.json  output.pptx
"""

import json
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Emu, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN
    from pptx.oxml.ns import qn
    from lxml import etree
except ImportError:
    print("ERROR: python-pptx not installed. Run: pip install python-pptx")
    sys.exit(1)


# ── Color palette (all hex strings without #) ────────────────────────────────
C = {
    "navy":         RGBColor(0x00, 0x14, 0x4A),
    "white":        RGBColor(0xFF, 0xFF, 0xFF),
    "black":        RGBColor(0x00, 0x00, 0x00),
    "blue_badge":   RGBColor(0x1B, 0x90, 0xFF),
    "base_light":   RGBColor(0xD1, 0xEF, 0xFF),
    "base_row":     RGBColor(0x00, 0x70, 0xF2),
    "premium":      RGBColor(0xE6, 0xA8, 0x00),
    "beta":         RGBColor(0x99, 0x99, 0x99),
    "joule":        RGBColor(0x5D, 0x36, 0xFF),
    "green":        RGBColor(0x10, 0x7E, 0x3E),
    "inactive_dot": RGBColor(0x00, 0x70, 0xF2),
    "row_bg":       RGBColor(0xF4, 0xFB, 0xF6),
    "row_border":   RGBColor(0xEA, 0xEC, 0xEE),
    "kpi_text":     RGBColor(0xD1, 0xEF, 0xFF),
    "col_label":    RGBColor(0x89, 0xD1, 0xFF),
    "subtitle":     RGBColor(0x66, 0x66, 0x66),
    "footer_bg":    RGBColor(0xEA, 0xEC, 0xEE),
    "stat_total":   RGBColor(0x00, 0x14, 0x4A),
    "stat_action":  RGBColor(0x10, 0x7E, 0x3E),
    "stat_expand":  RGBColor(0x00, 0x70, 0xF2),
    "stat_base":    RGBColor(0x1B, 0x90, 0xFF),
    "stat_prem":    RGBColor(0xE6, 0xA8, 0x00),
    "stat_joule":   RGBColor(0x5D, 0x36, 0xFF),
}

# ── Slide dimensions (widescreen 13.33" × 7.5") ──────────────────────────────
SLIDE_W = 12192000
SLIDE_H = 6858000

# ── Layout constants (EMU) ───────────────────────────────────────────────────
MARGIN_L      = 487680       # left / right margin
HEADER_H      = 731520       # 0.8"
BADGE_X       = 9570720
BADGE_Y       = 121920
BADGE_W       = 2255520
BADGE_H       = 463296

SUBTITLE_Y    = 755904
SUBTITLE_H    = 268224

LEGEND_Y      = 1048512
LEGEND_H      = 268224
DOT_Y_LEGEND  = 1097280
DOT_SZ_LEGEND = 170688

SEPARATOR_Y   = 1341120
CONTENT_W     = 11216640     # SLIDE_W - 2*MARGIN_L

COL_W         = 2740152      # column width
COL_GAP       = 85344        # gap between columns
COL_HEADER_Y  = 1377696
COL_HEADER_H  = 512064
KPI_Y_OFF     = 292608       # KPI y-offset within header

FIRST_ROW_Y   = 1950720
ROW_H         = 438912
DOT_R         = 109728       # dot diameter
DOT_X_OFF     = 73152        # dot x-offset within column
DOT_Y_OFF     = 158496       # dot y-offset within row
BADGE_X_OFF   = 2215896      # badge x-offset within column
BADGE_ROW_W   = 463296
BADGE_ROW_H   = 182880
JOULE_H       = 158496
FEAT_TEXT_X   = 207360       # feature name text x-offset within column
FEAT_TEXT_W   = 2008536      # feature text area width (before badge)

FOOTER_BG_Y   = 6364224
FOOTER_BG_H   = 518160
STAT_Y        = 6388608
STAT_H        = 268224
LABEL_Y       = 6656832
LABEL_H       = 219456
STAT_W        = 2032000      # each stat column width


# ── Helper: add rectangle ────────────────────────────────────────────────────
def add_rect(slide, x, y, w, h, fill_color, border_color=None, border_w=None):
    sp = slide.shapes.add_shape(1, Emu(x), Emu(y), Emu(w), Emu(h))
    sp.fill.solid()
    sp.fill.fore_color.rgb = fill_color
    if border_color:
        sp.line.color.rgb = border_color
        sp.line.width = Emu(border_w or 6350)
    else:
        sp.line.fill.background()
    return sp


# ── Helper: add textbox ──────────────────────────────────────────────────────
def add_textbox(slide, x, y, w, h, paragraphs, vcenter=False, align=PP_ALIGN.LEFT):
    """
    paragraphs: list of paragraph dicts:
      [{"runs": [{"text": str, "size": float, "bold": bool, "italic": bool,
                  "color": RGBColor}]}]
    """
    txBox = slide.shapes.add_textbox(Emu(x), Emu(y), Emu(w), Emu(h))
    tf    = txBox.text_frame
    tf.word_wrap = True

    # Remove default padding
    bp = tf._txBody.bodyPr
    bp.set("lIns", "0")
    bp.set("tIns", "0")
    bp.set("rIns", "0")
    bp.set("bIns", "0")
    if vcenter:
        bp.set("anchor", "ctr")

    # Clear default paragraph
    tf._txBody.clear()
    # Re-add bodyPr (cleared above)
    from pptx.oxml import parse_xml
    tf._txBody.append(parse_xml(
        f'<a:bodyPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
        f' wrap="square" lIns="0" tIns="0" rIns="0" bIns="0"'
        f' rtlCol="0"{"  anchor=\"ctr\"" if vcenter else ""}></a:bodyPr>'
    ))
    tf._txBody.append(parse_xml(
        '<a:lstStyle xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"/>'
    ))

    a_ns = "http://schemas.openxmlformats.org/drawingml/2006/main"

    for para_idx, para in enumerate(paragraphs):
        p_el = etree.SubElement(tf._txBody, f"{{{a_ns}}}p")
        # paragraph properties
        pPr = etree.SubElement(p_el, f"{{{a_ns}}}pPr")
        align_map = {PP_ALIGN.LEFT: "l", PP_ALIGN.CENTER: "ctr", PP_ALIGN.RIGHT: "r"}
        pPr.set("algn", align_map.get(para.get("align", align), "l"))
        pPr.set("marL", "0")
        pPr.set("indent", "0")

        for run in para.get("runs", []):
            r_el  = etree.SubElement(p_el, f"{{{a_ns}}}r")
            rPr   = etree.SubElement(r_el, f"{{{a_ns}}}rPr")
            rPr.set("lang", "en-US")
            rPr.set("sz",   str(int(run.get("size", 10) * 100)))
            if run.get("bold"):    rPr.set("b", "1")
            if run.get("italic"):  rPr.set("i", "1")
            rPr.set("dirty", "0")
            # color
            col = run.get("color", C["black"])
            sf  = etree.SubElement(rPr, f"{{{a_ns}}}solidFill")
            sc  = etree.SubElement(sf,  f"{{{a_ns}}}srgbClr")
            sc.set("val", f"{col[0]:02X}{col[1]:02X}{col[2]:02X}")
            # font
            for tag in ("latin", "ea", "cs"):
                fn = etree.SubElement(rPr, f"{{{a_ns}}}{tag}")
                fn.set("typeface", "72 Brand")
            # text
            t_el = etree.SubElement(r_el, f"{{{a_ns}}}t")
            t_el.text = run.get("text", "")

        # end paragraph run
        endPr = etree.SubElement(p_el, f"{{{a_ns}}}endParaRPr")
        endPr.set("lang", "en-US")
        endPr.set("sz", str(int(para.get("runs", [{}])[-1].get("size", 10) * 100
                             if para.get("runs") else 1000)))
        endPr.set("dirty", "0")

    return txBox


# ── Helper: add vertical separator line ──────────────────────────────────────
def add_vline(slide, x, y, h, color, w=6350):
    connector = slide.shapes.add_connector(1, Emu(x), Emu(y), Emu(x), Emu(y + h))
    connector.line.color.rgb = color
    connector.line.width = Emu(w)


# ── Helper: add horizontal line ──────────────────────────────────────────────
def add_hline(slide, x, y, length, color, w=9525):
    connector = slide.shapes.add_connector(1, Emu(x), Emu(y), Emu(x + length), Emu(y))
    connector.line.color.rgb = color
    connector.line.width = Emu(w)


# ── Helper: add ellipse (dot) ─────────────────────────────────────────────────
def add_ellipse(slide, x, y, d, color):
    sp = slide.shapes.add_shape(9, Emu(x), Emu(y), Emu(d), Emu(d))  # 9 = ellipse
    sp.fill.solid()
    sp.fill.fore_color.rgb = color
    sp.line.fill.background()
    return sp


# ── Build the slide ───────────────────────────────────────────────────────────
def build_slide(data: dict, output_path: str):
    prs = Presentation()
    prs.slide_width  = Emu(SLIDE_W)
    prs.slide_height = Emu(SLIDE_H)

    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank

    title_text = data.get("title", "AI Adoption Potential — Cloud ERP")
    subtitle    = data.get("subtitle", "")
    groups      = data.get("groups", [])[:4]  # max 4 columns
    stats       = data.get("stats", {})

    # ── HEADER BAR ────────────────────────────────────────────────────────────
    add_rect(slide, 0, 0, SLIDE_W, HEADER_H, C["navy"])

    # Title
    add_textbox(slide, MARGIN_L, 60960, 9144000, 609600,
                [{"runs": [{"text": title_text, "size": 20, "bold": True, "color": C["white"]}]}],
                vcenter=True)

    # Feature count badge
    feat_count = stats.get("total", 0)
    add_rect(slide, BADGE_X, BADGE_Y, BADGE_W, BADGE_H, C["blue_badge"])
    add_textbox(slide, BADGE_X, BADGE_Y, BADGE_W, BADGE_H,
                [{"align": PP_ALIGN.CENTER, "runs": [
                    {"text": f"{feat_count} AI Features Mapped",
                     "size": 10, "bold": True, "color": C["white"]}
                ]}], vcenter=True)

    # ── SUBTITLE ──────────────────────────────────────────────────────────────
    add_textbox(slide, MARGIN_L, SUBTITLE_Y, CONTENT_W, SUBTITLE_H,
                [{"runs": [{"text": subtitle, "size": 9.33, "italic": True,
                            "color": C["subtitle"]}]}], vcenter=True)

    # ── LEGEND ────────────────────────────────────────────────────────────────
    # Green square
    add_rect(slide, MARGIN_L, DOT_Y_LEGEND, DOT_SZ_LEGEND, DOT_SZ_LEGEND, C["green"])
    add_textbox(slide, 707136, LEGEND_Y, 2072640, LEGEND_H,
                [{"runs": [{"text": "Active SC — deploy AI now",
                            "size": 8, "color": C["black"]}]}], vcenter=True)
    # Blue square
    add_rect(slide, 2865120, DOT_Y_LEGEND, DOT_SZ_LEGEND, DOT_SZ_LEGEND, C["inactive_dot"])
    add_textbox(slide, 3084576, LEGEND_Y, 2438400, LEGEND_H,
                [{"runs": [{"text": "Inactive SC — AI accelerates adoption",
                            "size": 8, "color": C["black"]}]}], vcenter=True)
    # Base badge (legend)
    add_rect(slide, 5608320, 1085088, 463296, 207264, C["base_light"])
    add_textbox(slide, 5608320, 1085088, 463296, 207264,
                [{"align": PP_ALIGN.CENTER, "runs": [
                    {"text": "Base", "size": 7.5, "color": C["navy"]}]}], vcenter=True)
    add_textbox(slide, 6120384, LEGEND_Y, 2072640, LEGEND_H,
                [{"runs": [{"text": "Included in S/4HANA license",
                            "size": 8, "color": C["black"]}]}], vcenter=True)
    # Premium badge (legend)
    add_rect(slide, 8290560, 1085088, 633984, 207264, C["premium"])
    add_textbox(slide, 8290560, 1085088, 633984, 207264,
                [{"align": PP_ALIGN.CENTER, "runs": [
                    {"text": "Premium", "size": 7.5, "color": C["white"]}]}], vcenter=True)
    add_textbox(slide, 8973312, LEGEND_Y, 2194560, LEGEND_H,
                [{"runs": [{"text": "Additional license required",
                            "size": 8, "color": C["black"]}]}], vcenter=True)

    # Separator line
    add_hline(slide, MARGIN_L, SEPARATOR_Y, CONTENT_W, C["row_border"])

    # ── COLUMNS ───────────────────────────────────────────────────────────────
    for col_idx, group in enumerate(groups):
        cx = MARGIN_L + col_idx * (COL_W + COL_GAP)

        # Column header background
        add_rect(slide, cx, COL_HEADER_Y, COL_W, COL_HEADER_H, C["navy"])

        # Group label + title (on same line)
        gid   = group.get("id", f"G{col_idx+1}")
        gtitle = group.get("title", "")
        add_textbox(slide, cx + 85344, COL_HEADER_Y + 24384, COL_W - 170688, 268224,
                    [{"runs": [
                        {"text": gid + "  ", "size": 10.67, "bold": True,
                         "color": C["col_label"]},
                        {"text": gtitle, "size": 10.67, "bold": True,
                         "color": C["white"]},
                    ]}], vcenter=True)

        # KPI
        kpi = group.get("kpi", "")
        add_textbox(slide, cx + 85344, COL_HEADER_Y + KPI_Y_OFF, COL_W - 170688, 195072,
                    [{"runs": [{"text": kpi, "size": 7.5, "italic": True,
                                "color": C["kpi_text"]}]}], vcenter=True)

        # ── Feature rows ───────────────────────────────────────────────────
        for row_idx, feat in enumerate(group.get("features", [])):
            ry = FIRST_ROW_Y + row_idx * ROW_H

            # Row background
            add_rect(slide, cx, ry, COL_W, ROW_H, C["row_bg"],
                     border_color=C["row_border"], border_w=6350)

            # Colored dot
            dot_color = C["green"] if feat["status"] == "Active" else C["inactive_dot"]
            add_ellipse(slide,
                        cx + DOT_X_OFF,
                        ry + DOT_Y_OFF,
                        DOT_R, dot_color)

            # Badge (Base / Premium / Beta)
            badge = feat.get("badge", "Base")
            if badge == "Premium":
                badge_bg   = C["premium"]
                badge_tc   = C["white"]
                badge_text = "Prem"
                badge_w    = BADGE_ROW_W
            elif badge == "Beta":
                badge_bg   = C["beta"]
                badge_tc   = C["white"]
                badge_text = "Beta"
                badge_w    = BADGE_ROW_W
            else:
                badge_bg   = C["base_row"]
                badge_tc   = C["white"]
                badge_text = "Base"
                badge_w    = BADGE_ROW_W

            add_rect(slide, cx + BADGE_X_OFF, ry + 24384, badge_w, BADGE_ROW_H, badge_bg)
            add_textbox(slide, cx + BADGE_X_OFF, ry + 24384, badge_w, BADGE_ROW_H,
                        [{"align": PP_ALIGN.CENTER, "runs": [
                            {"text": badge_text, "size": 7, "color": badge_tc}
                        ]}], vcenter=True)

            # Joule badge (below main badge)
            if feat.get("is_joule"):
                joule_y = ry + 24384 + BADGE_ROW_H + 12192
                add_rect(slide, cx + BADGE_X_OFF, joule_y, badge_w, JOULE_H, C["joule"])
                add_textbox(slide, cx + BADGE_X_OFF, joule_y, badge_w, JOULE_H,
                            [{"align": PP_ALIGN.CENTER, "runs": [
                                {"text": "Joule", "size": 7, "color": C["white"]}
                            ]}], vcenter=True)

            # Feature name (bold, black)
            add_textbox(slide, cx + FEAT_TEXT_X, ry + 12192, FEAT_TEXT_W, 219456,
                        [{"runs": [{"text": feat["name"], "size": 8.5,
                                    "bold": True, "color": C["black"]}]}],
                        vcenter=True)

            # Capability text (italic, gray, smaller)
            cap = feat.get("capability", "")
            if cap:
                add_textbox(slide, cx + FEAT_TEXT_X, ry + 243840, FEAT_TEXT_W, 170688,
                            [{"runs": [{"text": cap, "size": 7.5,
                                        "italic": True, "color": C["subtitle"]}]}],
                            vcenter=True)

    # ── FOOTER ────────────────────────────────────────────────────────────────
    add_rect(slide, 0, FOOTER_BG_Y, SLIDE_W, FOOTER_BG_H, C["footer_bg"])

    footer_stats = [
        (stats.get("total", 0),                  C["stat_total"],  ["AI Features", "Mapped"]),
        (stats.get("immediately_actionable", 0),  C["stat_action"], ["Immediately", "Actionable"]),
        (stats.get("expansion_opportunities", 0), C["stat_expand"], ["Expansion", "Opportunities"]),
        (stats.get("base_included", 0),           C["stat_base"],   ["Base License", "Included"]),
        (stats.get("premium_required", 0),        C["stat_prem"],   ["Premium", "Required"]),
        (stats.get("joule_enabled", 0),           C["stat_joule"],  ["Joule-", "Enabled"]),
    ]

    for i, (val, color, label_lines) in enumerate(footer_stats):
        sx = i * STAT_W
        # Vertical separator (except first)
        if i > 0:
            add_vline(slide, sx, 6425184, 390144, C["subtitle"])
        # Number
        add_textbox(slide, sx, STAT_Y, STAT_W, STAT_H,
                    [{"align": PP_ALIGN.CENTER, "runs": [
                        {"text": str(val), "size": 17, "bold": True, "color": color}
                    ]}], vcenter=True, align=PP_ALIGN.CENTER)
        # Label (two lines)
        for li, ltext in enumerate(label_lines):
            ly = LABEL_Y + li * (LABEL_H // 2)
            add_textbox(slide, sx, ly, STAT_W, LABEL_H // 2,
                        [{"align": PP_ALIGN.CENTER, "runs": [
                            {"text": ltext, "size": 7, "color": C["subtitle"]}
                        ]}], vcenter=True, align=PP_ALIGN.CENTER)

    prs.save(output_path)
    print(f"Saved: {output_path}")


# ── CLI ───────────────────────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 3:
        print("Usage: python create_slide.py <slide_data.json> <output.pptx>")
        sys.exit(1)
    json_path = sys.argv[1]
    out_path  = sys.argv[2]
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)
    build_slide(data, out_path)


if __name__ == "__main__":
    main()
