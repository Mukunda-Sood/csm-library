#!/usr/bin/env python3
"""
create_template.py — AI Adoption Potential Skill
Generates a BLANK Excel template for the user to fill in with their
customer's solution capability usage data.

NO pre-filled data rows are included. The user must populate this file
with their actual customer data before the slide can be generated.

Usage:
  python scripts/create_template.py
  # → assets/Solution_Capability_Usage_Template.xlsx
"""

import sys
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)


def create_template():
    wb = openpyxl.Workbook()

    # ── Capabilities sheet ────────────────────────────────────────────────────
    ws = wb.active
    ws.title = "Capabilities"

    headers = ["Group", "Group Title", "KPI", "Feature ID",
               "Solution Capability", "Status", "Feature Name"]

    # Header style
    header_fill  = PatternFill("solid", fgColor="00144A")
    header_font  = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font  = header_font
        cell.fill  = header_fill
        cell.alignment = header_align

    # No data rows — the user must fill in their own customer data.
    # Leave the sheet empty below the header row.

    # Column widths
    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 38
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 35
    ws.column_dimensions["F"].width = 12
    ws.column_dimensions["G"].width = 35
    ws.row_dimensions[1].height = 30

    # Freeze header
    ws.freeze_panes = "A2"

    # ── Instructions sheet ────────────────────────────────────────────────────
    ws2 = wb.create_sheet("Instructions")
    ws2.column_dimensions["A"].width = 20
    ws2.column_dimensions["B"].width = 60

    instructions = [
        ("Column", "Description"),
        ("Group", "Column ID: G1, G2, G3, or G4"),
        ("Group Title", "Column heading shown on slide (e.g. Faster Close & Automation)"),
        ("KPI", "KPI subtitle for the column (e.g. KPI: Close time, cost/transaction)"),
        ("Feature ID", "Identifier from AI Features Data.csv (e.g. J74, J88)"),
        ("Solution Capability", "Capability name shown under the feature on the slide"),
        ("Status", "Active (green dot) or Inactive (blue dot)"),
        ("Feature Name", "(Optional) Short display name. If blank, uses full name from CSV."),
        ("", ""),
        ("Max features/column", "~9 rows before content overflow"),
        ("Max columns", "4 (G1–G4)"),
        ("Badge types", "Determined automatically from AI Features Data.csv"),
        ("", ""),
        ("Find Feature IDs", "Open data/AI Features Data.csv, search by feature name,"),
        ("", "copy the Identifier column value (e.g. J74)"),
    ]

    h_font = Font(name="Calibri", bold=True, size=11, color="00144A")
    d_font = Font(name="Calibri", size=10)
    for r, (col_a, col_b) in enumerate(instructions, start=1):
        ws2.cell(row=r, column=1, value=col_a).font = h_font if r == 1 else d_font
        ws2.cell(row=r, column=2, value=col_b).font = d_font

    # Save
    out_dir = Path(__file__).parent.parent / "assets"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "Solution_Capability_Usage_Template.xlsx"
    wb.save(out_path)
    print(f"Template saved: {out_path}")
    return str(out_path)


if __name__ == "__main__":
    create_template()
