---
name: level0-health-read-v3
description: Generate Level 0 Account Health Reads from Order Form, cACV, and Benchmark data. Produces a strategic narrative HTML dashboard and PPTX board deck with embedded VLM (Value Lifecycle Management) Value Drivers — written at the quality of a top 1% CSM presenting to a Board. Industry-agnostic: works for any SAP product portfolio (Ariba, S/4HANA, SuccessFactors, CX, BTP). Use when the user provides customer contract/usage data and asks for an account health assessment, health read, or Level 0 analysis.
---

# Level 0 Account Health Read (v3)

## Purpose

Generate a **diagnostic strategic narrative** — not a metrics report — from three data sources:
1. **Order Form (OF)** — Contract structure, SKUs, fees, terms, escalators, credits
2. **cACV file** — Monthly consumption vs. entitlement per module
3. **Benchmark Report (BM)** — Peer cohort positioning, aggregate volumes, detail metrics

The output is what a top 1% CSM would present at an internal alignment meeting: a document that tells a *story*, connects *non-obvious dots*, creates *productive tension*, and maps every insight to a **VLM Value Driver** with KPI/P&L metadata.

## Critical Mindset: Diagnostician, Not Reporter

A reporter says: "Sourcing is at 0% utilization."
A diagnostician says: "Your supplier base is 9x more concentrated than peers — each relationship averages $388K. This is the EXACT profile where fewer sourcing events produce disproportionate ROI. Yet zero events have been run."

### The Five Diagnostic Questions (ask of every metric)

1. **Why is this number what it is?** (root cause, not just observation)
2. **What does this number make impossible?** (downstream consequence)
3. **What proof exists that the fix already works?** (the "0.99-day proof point" pattern)
4. **Who in the org experiences this pain daily?** (stakeholder mapping)
5. **What happens if we don't act before renewal?** (business urgency)

## Workflow

### Step 1: Extract Data

Extract from all three sources. Store structured data in `/tmp/sandbox/work/account_data.json`.

**From Order Form**: Customer name, ID, case ID, signer (name + title), term dates, annual fee, escalator %, auto-renew terms, credit (amount + expiry), all SKUs (name, metric, limitation, annual fee), previous agreement reference (display in Contract Structure section for renewal history context).

**From cACV**: Each module with monthly cACV, monthly ACV, consumption %, line item IDs. Compute totals. Note which OF SKUs are NOT tracked in cACV (blind spots).

**From Benchmark**: Cohort (industry, region), measurement period. Scorecard metrics with company value + B25/Avg/T25 + position. Detail metrics. ALL aggregate data including BLANK fields (BLANKs are diagnostic signals, not missing data).

### Step 2: Compute Derived Diagnostics

Go beyond raw numbers. Calculate:
- **Asymmetries**: Invoice vs PO Network %, Catalog lines vs Catalog spend, Entitlement vs Actual
- **Concentration signals**: Spend/supplier, suppliers/$M, spend/PO
- **Velocity gaps**: Compare fast-path (catalog R2O) vs slow-path (non-catalog R2O)
- **Utilization gaps**: Each SKU entitlement vs BM actual vs cACV consumption
- **BLANK fields as evidence**: BLANK ≠ missing. BLANK = zero activity = confirmed dormancy.
- **Renewal math**: Months remaining, defensible $ vs at-risk $, credit status

**Renewal Math Computation Rule**:
1. For each module, determine its Cross-Validation verdict (see `references/data-extraction.md`).
2. **Defensible $** = Sum of annual fees for modules with verdict "Confirmed Active" or "Partial/At Risk" (where adoption is demonstrable, even if below potential).
3. **At-Risk $** = Sum of annual fees for modules with verdict "Confirmed Dormant" or "Needs Investigation" (where zero or near-zero activity makes the fee indefensible at renewal without an activation plan).
4. Report credit amount separately as the activation investment vehicle.
5. The split must appear in PPTX Slide 7 (Renewal Math) and be referenced in the Timeline section.

### Step 3: Identify the Structural Narrative

**Do NOT start with metrics. Start with the story.**

The narrative must answer: "If I had 30 seconds with a Board member, what would I say?"

Pattern: `[Diagnostic observation] + [Why it matters for THIS customer] + [What's at stake in $ or time]`

Industry-agnostic patterns to look for:
- **The Asymmetry**: Two related metrics telling opposite stories (e.g., invoice at 100% but PO at 65%)
- **The Proof Point**: The system already solves the problem — for a tiny fraction of activity
- **The Concentration Lever**: Fewer, larger relationships = higher per-event ROI
- **The Missing Layer**: Licensed capabilities producing zero measurable activity
- **The Timing Pressure**: Renewal math forcing a decision window
- **The Billing Question**: cACV near-zero while BM shows activity flowing through adjacent module

See `references/narrative-principles.md` for full documentation of each pattern with templates and industry-agnostic examples.

**Pattern Selection for Output**: Not all 6 patterns will apply to every account. For the Structural Patterns section (Section 11 in the HTML dashboard), select the **4 patterns most strongly supported by this customer's data**. Each pattern card must cite evidence from at least 2 sources. If fewer than 4 patterns have multi-source support, use fewer cards rather than forcing weak patterns.

### Step 4: Write Strategic Themes (3 themes)

Each theme must have:
1. **Title** — A business-outcome statement, not a product-utilization label
2. **Dollar-at-risk or impact quantification**
3. **Impact narrative** — 3-5 sentences connecting dots across all 3 sources
4. **Evidence list** — Tagged by source [OF], [cACV], [BM]
5. **Stakeholder + Conversation Starter** — A sentence that creates tension, not reports findings
6. **VLM (Value Lifecycle Management) Value Drivers** — Tags from the VLM catalog (see `references/vlm-drivers.md`)
7. **Validation Questions** — What we need to learn before acting

**Conversation Starter Quality Test**: If the sentence could be generated by reading a dashboard, it fails. It must contain an insight the customer hasn't connected yet.

### Step 5: Write Hypotheses with Embedded VLM Drivers

Generate **4-6 hypotheses**. At least 2 must be CONFIRMED (triple-validated across all 3 sources); the remainder can be OPEN (require customer input to validate). Prioritize by business impact, not by data completeness.

Each hypothesis card includes:
- Priority badge (CRITICAL / HIGH / MODERATE)
- Status (CONFIRMED / OPEN)
- Title — phrased as a diagnostic finding, not a metric observation
- Evidence paragraph — cross-referencing all 3 sources in one narrative
- **VLM Value Drivers** — Each with: driver name, KPI name, P&L line (Top/Bottom), cost category (SG&A/COGS/Revenue/Pre-tax margin)

See `references/vlm-drivers.md` for the full catalog.

### Step 6: Build Engagement Sequence (4 touches)

| Touch | Name | Purpose |
|-------|------|---------|
| 1 | Internal Alignment | This document. Answer blocking questions (e.g., billing redundancy). |
| 2 | The Question Meeting | Open with the asymmetry/proof point. Ask WHY. Listen. |
| 3 | The Proof Meeting | Show the data that proves the fix works. Propose credit-funded activation. |
| 4 | The Ownership Meeting | Present to executive. Frame renewal as value acceleration. |

Each touch: timing, owner, exact opening line/approach, success criteria.

### Step 7: Generate HTML Dashboard

Use the CSS and structure from `assets/template.css` and `references/html-structure.md`.

**Output filename**: `{{Customer_Name}}_Level0_Health_Read_{{YYYY-MM-DD}}.html` (placed in `/tmp/sandbox/`).

**Threshold Note**: The Entitlements vs Usage section uses capacity-based thresholds (>80% healthy, 30-80% partial, 1-30% low, 0% dormant) because it measures how much of the entitled capacity ceiling is being used. The Module Activation section uses billing-based thresholds (90-100% fully consumed, 50-89% partial, 1-49% low, 0% dormant) because cACV consumption near 100% means the billing cap is reached. These are intentionally different scales for different measurement contexts.

**Sections** (in order):
1. Sidebar navigation (fixed, dark navy)
2. Hero (customer name, date, industry, region, period)
3. Pattern Banner (diagnostic statement — the "30-second Board sentence")
4. KPI Strip (5 cards — choose the most DIAGNOSTIC metrics, not the most obvious)
5. Strategic Themes (3 cards with full evidence + VLM + conversation starters)
6. Engagement Sequence (4-touch grid)
7. Contract Structure (SKU table from OF)
8. Entitlements vs Usage (utilization bars)
9. Module Activation (cACV table with status badges)
10. Peer Position (scorecard table + structural signals + interpretation)
11. Structural Patterns (4 pattern cards)
12. Cross-Validation Matrix (3-source corroboration with verdict badges)
13. Hypotheses & VLM (hypothesis cards with embedded VLM drivers)
14. Timeline & Next Steps (contract timeline + immediate actions)
15. Footer (sources + disclaimer)

### Step 8: Generate PPTX Board Deck

**Output filename**: `{{Customer_Name}}_Level0_Board_Deck_{{YYYY-MM-DD}}.pptx` (placed in `/tmp/sandbox/`).

8 slides:
1. Cover (SAP branded, customer name, key contract facts)
2. The Diagnostic (pattern statement + 5 KPI boxes)
3. Theme 1 (title + evidence + VLM drivers)
4. Theme 2 (title + evidence + VLM drivers)
5. Theme 3 (title + evidence + VLM drivers)
6. Engagement Sequence (4 touch cards)
7. Renewal Math (defensible vs at-risk table)
8. The Ask (4 specific, time-bound actions)

Use `pptxgenjs` via the pptx skill. SAP brand colors from `/tmp/sandbox/skills/sap-brand/material/anvils/sap.svg`.

## Quality Checklist

Before delivering, verify:
- [ ] Pattern banner is a diagnostic statement, not a metrics summary
- [ ] Every conversation starter creates tension (not reports findings)
- [ ] The "proof point" pattern is used (system works for X% — expand it)
- [ ] Supplier concentration / structural signals are interpreted, not just cited
- [ ] BLANK fields are explicitly called out as confirmed dormancy signals
- [ ] VLM drivers are embedded IN hypothesis cards (not a separate section)
- [ ] Engagement sequence has exact opening lines, not generic descriptions
- [ ] Renewal math clearly shows defensible vs at-risk $ amounts with computation logic
- [ ] 4-6 hypotheses generated with at least 2 CONFIRMED
- [ ] All data comes from uploaded files — NEVER use example/fabricated numbers
- [ ] Industry context shapes interpretation (CPG ≠ Manufacturing ≠ Tech ≠ Energy ≠ FinServ ≠ Healthcare)
- [ ] Output filenames follow naming convention

## References

- **Narrative principles & diagnostic thinking**: See `references/narrative-principles.md`
- **VLM Value Driver catalog**: See `references/vlm-drivers.md`
- **HTML structure & CSS**: See `references/html-structure.md`
- **CSS template file**: See `assets/template.css`
- **Data extraction guide**: See `references/data-extraction.md`

## Triggers

Use this skill when:
- User provides OF/cACV/BM files and asks for a "health read" or "Level 0"
- User asks for an "account health assessment" with customer data files
- User mentions "health read" + provides contract/benchmark/usage documents
- User asks you to "run the Level 0 analysis" on provided files

## Important Notes

- This skill is **industry-agnostic** — works for Ariba, S/4HANA, SuccessFactors, CX, BTP, or any SAP product portfolio
- The three source types (OF/cACV/BM) map to any SAP product: OF = contract, cACV = consumption billing, BM = benchmarking data (may be called different names for non-Ariba products)
- If fewer than 3 sources are available, proceed with what's given but call out which cross-validations cannot be performed
- NEVER fabricate data. Every number in the output must trace to a specific source file.
- The narrative must be specific to THIS customer. Generic advice = failure.
- This skill supersedes level0-health-read (v1). If both are installed, use v3 exclusively.
- For a worked example of this methodology applied to a real account, refer to the Level 0 Playbook document.
