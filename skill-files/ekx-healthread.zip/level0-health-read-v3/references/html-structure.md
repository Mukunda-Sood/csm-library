# HTML Dashboard Structure Reference

## Overview

The Level 0 Health Read HTML dashboard is a single-page, self-contained HTML file with:
- Embedded CSS (from `assets/template.css`)
- Fixed sidebar navigation
- Responsive content sections
- No external JS dependencies (pure CSS interactions)

## Document Skeleton

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{CUSTOMER_NAME}} | Level 0 Account Health Read</title>
<style>
/* Paste contents of assets/template.css here */
</style>
</head>
<body>

<!-- 1. SIDEBAR NAVIGATION -->
<nav class="sidebar">
    <div class="sidebar-brand">
        <!-- SAP logo SVG (inline) -->
    </div>
    <div class="sidebar-meta">
        <div class="label">Level 0 Health Read</div>
        <div class="customer-name">{{CUSTOMER_NAME}}</div>
    </div>
    <div class="sidebar-nav">
        <a class="nav-link active" href="#overview">Overview</a>
        <a class="nav-link" href="#themes">Strategic Themes</a>
        <a class="nav-link" href="#engagement">Engagement Sequence</a>
        <a class="nav-link" href="#contracts">Contract Structure</a>
        <a class="nav-link" href="#entitlements">Entitlements vs. Usage</a>
        <a class="nav-link" href="#activation">Module Activation</a>
        <a class="nav-link" href="#peer">Peer Position</a>
        <a class="nav-link" href="#patterns">Structural Patterns</a>
        <a class="nav-link" href="#crossval">Cross-Validation</a>
        <a class="nav-link" href="#hypotheses">Hypotheses & VLM</a>
        <a class="nav-link" href="#timeline">Timeline & Next Steps</a>
        <div class="nav-divider"></div>
        <a class="nav-link" href="#sources">Data Sources</a>
    </div>
    <div class="sidebar-footer">
        <div class="source-count">3 data sources triangulated</div>
    </div>
</nav>

<!-- 2. MAIN CONTENT -->
<div class="main">

    <!-- 3. HERO -->
    <header class="hero" id="overview">
        <div class="hero-content">
            <h1>{{CUSTOMER_NAME}}</h1>
            <div class="subtitle">Level 0 Account Health Read</div>
            <div class="meta-row">
                <div class="meta-item"><span>{{DATE}}</span></div>
                <div class="meta-item">Industry: <span>{{INDUSTRY}}</span></div>
                <div class="meta-item">Region: <span>{{REGION}}</span></div>
                <div class="meta-item">Period: <span>{{MEASUREMENT_PERIOD}}</span></div>
            </div>
        </div>
    </header>

    <!-- 4. PATTERN BANNER -->
    <div class="pattern-banner">
        <div class="pb-label">Identified Trajectory Pattern</div>
        <div class="pb-name">{{PATTERN_TITLE}}</div>
        <div class="pb-desc">{{PATTERN_DESCRIPTION}}</div>
    </div>

    <!-- 5. CONTENT WRAPPER -->
    <div class="content">

        <!-- 6. KPI STRIP (5 cards) -->
        {{KPI_STRIP}}

        <!-- 7. STRATEGIC THEMES (3 cards) -->
        {{THEMES_SECTION}}

        <!-- 8. ENGAGEMENT SEQUENCE -->
        {{ENGAGEMENT_SECTION}}

        <!-- 9. CONTRACT STRUCTURE -->
        {{CONTRACT_SECTION}}

        <!-- 10. ENTITLEMENTS VS USAGE -->
        {{ENTITLEMENTS_SECTION}}

        <!-- 11. MODULE ACTIVATION -->
        {{ACTIVATION_SECTION}}

        <!-- 12. PEER POSITION -->
        {{PEER_SECTION}}

        <!-- 13. STRUCTURAL PATTERNS -->
        {{PATTERNS_SECTION}}

        <!-- 14. CROSS-VALIDATION MATRIX -->
        {{CROSSVAL_SECTION}}

        <!-- 15. HYPOTHESES & VLM -->
        {{HYPOTHESES_SECTION}}

        <!-- 16. TIMELINE & NEXT STEPS -->
        {{TIMELINE_SECTION}}

        <!-- 17. FOOTER -->
        {{FOOTER}}

    </div>
</div>
</body>
</html>
```

---

## Section Templates

### SAP Logo SVG (for sidebar)

```html
<svg viewBox="0 0 412.4 204" height="28" xmlns="http://www.w3.org/2000/svg">
    <defs>
        <linearGradient id="sap_nav_grad" x1="206.19" y1="206" x2="206.19" y2="2" gradientTransform="matrix(1 0 0 -1 0 206)" gradientUnits="userSpaceOnUse">
            <stop offset="0" style="stop-color:#00B8F1"/>
            <stop offset="0.31" style="stop-color:#0D90D9"/>
            <stop offset="0.58" style="stop-color:#1775C8"/>
            <stop offset="1" style="stop-color:#1E5FBB"/>
        </linearGradient>
    </defs>
    <polyline fill="url(#sap_nav_grad)" fill-rule="evenodd" clip-rule="evenodd" points="0,204 208.4,204 412.4,0 0,0 0,204"/>
    <path fill="#FFFFFF" fill-rule="evenodd" clip-rule="evenodd" d="M244.7,38.4h-40.6v96.5l-35.5-96.6h-35.2l-30.3,80.7C100,98.7,79,91.7,62.4,86.4C51.5,82.9,39.8,77.7,40,72c0.1-4.7,6.2-9,18.4-8.4c8.2,0.4,15.4,1.1,29.7,8l14.1-24.5c-13.1-6.6-31.2-10.9-46-10.9h-0.1c-17.3,0-31.7,5.6-40.6,14.8c-6.2,6.3-9.7,14.8-9.7,23.7C5.5,87.2,10.1,96,19.7,103c8.1,5.9,18.5,9.8,27.6,12.6c11.3,3.5,20.5,6.5,20.4,13c-0.1,2.4-1,4.7-2.7,6.4c-2.8,2.9-7.1,4-13.1,4.1c-11.5,0.2-20-1.6-33.6-9.6L5.8,154.4c14,8,29.9,12.2,46,12.2h2.1c14.2-0.2,25.7-4.3,34.9-11.7c0.5-0.4,1-0.8,1.5-1.3l-4.1,10.9H123l6.2-18.8c7,2.3,14.3,3.5,21.7,3.4c7.2,0,14.3-1.1,21.2-3.2l6,18.6h60.1v-39h13.1c31.7,0,50.5-16.2,50.5-43.2C301.7,52.2,283.5,38.4,244.7,38.4z M150.9,121c-4.4,0-8.8-0.7-13-2.3l12.9-40.6h0.2l12.6,40.7C159.6,120.3,155.2,121,150.9,121z M247.1,97.7h-8.9V64.9h8.9c11.9,0,21.4,4,21.4,16.1C268.5,93.7,259,97.6,247.1,97.7"/>
</svg>
```

### KPI Strip (5 cards)

```html
<div class="kpi-strip">
    <div class="kpi-card">
        <div class="kpi-value">{{VALUE}}</div>
        <div class="kpi-label">{{LABEL}}</div>
        <div class="kpi-sub">{{CONTEXT}}</div>
    </div>
    <!-- Use class "kpi-highlight" for the 2 most diagnostic KPIs -->
    <div class="kpi-card kpi-highlight">
        <div class="kpi-value">{{VALUE}}</div>
        <div class="kpi-label">{{LABEL}}</div>
        <div class="kpi-sub">{{CONTEXT}}</div>
    </div>
    <!-- Repeat for 5 total cards -->
</div>
```

**KPI Selection Guidance**: Choose the 5 metrics that are most DIAGNOSTIC — not the biggest numbers. Diagnostic means they reveal a root cause or structural decision. At least 2 should show an asymmetry or contradiction.

### Theme Card

```html
<div class="theme-card">
    <div class="theme-header">
        <span class="theme-number">Theme {{N}}</span>
        <span class="theme-risk">{{DOLLAR_AT_RISK_OR_IMPACT}}</span>
    </div>
    <div class="theme-title">{{BUSINESS_OUTCOME_TITLE}}</div>
    <div class="theme-impact">{{NARRATIVE_PARAGRAPH}}</div>
    <div class="theme-section-label">Evidence</div>
    <ul class="theme-evidence">
        <li><span class="source-tag tag-bm">BM</span> {{EVIDENCE_ITEM}}</li>
        <li><span class="source-tag tag-cacv">cACV</span> {{EVIDENCE_ITEM}}</li>
        <li><span class="source-tag tag-of">OF</span> {{EVIDENCE_ITEM}}</li>
    </ul>
    <div class="theme-section-label">Stakeholder & Conversation Starter</div>
    <div class="theme-stakeholder"><strong>{{STAKEHOLDER_TITLE}}</strong></div>
    <div class="theme-conversation">"{{TENSION_CREATING_QUESTION}}"</div>
    <div class="theme-section-label">VLM Value Drivers</div>
    <div class="theme-vlm-list">
        <span class="theme-vlm-tag">{{DRIVER_NAME}}</span>
        <span class="theme-vlm-tag">{{DRIVER_NAME}}</span>
    </div>
    <div class="theme-section-label">Validation Questions</div>
    <ul class="theme-validation">
        <li>{{QUESTION}}</li>
    </ul>
</div>
```

### Engagement Touch Card

```html
<div class="engagement-grid">
    <div class="engagement-touch">
        <div class="touch-header">
            <span class="touch-number">Touch {{N}}</span>
            <span class="touch-timing">{{TIMING}}</span>
        </div>
        <div class="touch-title">{{TOUCH_NAME}}</div>
        <div class="touch-content">{{DETAILED_DESCRIPTION}}</div>
        <div class="touch-meta">
            <span class="touch-meta-item"><strong>Critical gate:</strong> {{GATE}}</span>
            <span class="touch-meta-item"><strong>Owner:</strong> {{OWNER}}</span>
            <span class="touch-meta-item"><strong>Success:</strong> {{SUCCESS_CRITERIA}}</span>
        </div>
    </div>
    <!-- Repeat for 4 touches -->
</div>
```

### Contract Structure (Order Form)

```html
<section id="contracts">
    <div class="section-header">
        <div class="section-title">Contract Structure</div>
        <span class="source-tag tag-of">ORDER FORM</span>
    </div>
    <div class="of-card">
        <div class="of-header">
            <span class="of-title">{{ORDER_FORM_TITLE}}</span>
            <span class="source-tag tag-of">ORDER FORM</span>
        </div>
        <table class="of-meta">
            <tr><td class="meta-label">Case ID</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Signed</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Term</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Annual Fee</td><td class="meta-value fee-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Escalator</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Auto-Renew</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Signer</td><td class="meta-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Credit</td><td class="meta-value credit-value">{{VALUE}}</td></tr>
            <tr><td class="meta-label">Previous Agreement</td><td class="meta-value">{{VALUE_OR_NONE}}</td></tr>
        </table>
        <div class="sku-table-wrap">
            <table class="sku-table">
                <thead><tr><th>Cloud Service</th><th>Metric</th><th class="num">Limitation</th><th class="num">Annual Fee</th></tr></thead>
                <tbody>
                    <tr><td>{{SKU_NAME}}</td><td>{{METRIC}}</td><td class="num">{{LIMIT}}</td><td class="num">{{FEE}}</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
```

### Entitlements vs Usage

```html
<section id="entitlements">
    <div class="section-header">
        <div class="section-title">Entitlement vs. Actual Usage</div>
        <span class="source-tag tag-of">OF</span>
        <span class="source-tag tag-bm">BM</span>
    </div>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr><th>SKU</th><th class="num">Entitlement</th><th class="num">Actual (BM period)</th><th>Utilization</th><th class="num">Annual Fee</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{SKU}}</td>
                    <td class="num">{{ENTITLEMENT}}</td>
                    <td class="num">{{ACTUAL}}</td>
                    <td>
                        <div class="util-bar-wrap">
                            <div class="util-bar {{BAR_CLASS}}" style="width:{{PCT}}%"></div>
                        </div>
                        <span class="util-pct">{{PCT}}%</span>
                    </td>
                    <td class="num">{{FEE}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</section>
```

**Bar classes**: `bar-healthy` (>80%), `bar-partial` (30-80%), `bar-low` (1-30%), `bar-dormant` (0%)

### Module Activation (cACV)

```html
<section id="activation">
    <div class="section-header">
        <div class="section-title">Module Activation Status</div>
        <span class="source-tag tag-cacv">cACV</span>
        <span class="section-subtitle">{{MONTH_YEAR}}</span>
    </div>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr><th>Module</th><th class="num">Monthly cACV</th><th class="num">Monthly ACV</th><th>Consumption</th><th>Status</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td class="module-name">{{MODULE}}</td>
                    <td class="num">{{CACV}}</td>
                    <td class="num">{{ACV}}</td>
                    <td>
                        <div class="util-bar-wrap">
                            <div class="util-bar {{BAR_CLASS}}" style="width:{{PCT}}%"></div>
                        </div>
                        <span class="util-pct">{{PCT}}%</span>
                    </td>
                    <td><span class="status-badge {{DOT_CLASS}}">{{STATUS_TEXT}}</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</section>
```

**Status badges**: `dot-active` (Fully Consumed), `dot-partial` (Partial), `dot-low` (Low), `dot-dormant` (Dormant)

### Peer Position (Benchmark Scorecard)

```html
<section id="peer">
    <div class="section-header">
        <div class="section-title">Peer Position</div>
        <span class="source-tag tag-bm">BENCHMARK</span>
    </div>
    <div class="card">
        <div class="peer-meta">
            <span>Cohort: {{INDUSTRY}}, {{REGION}}</span>
            <span>Period: {{PERIOD}}</span>
        </div>
        <table class="data-table">
            <thead>
                <tr><th>Metric</th><th class="num">Company</th><th class="num">B25</th><th class="num">Avg</th><th class="num">T25</th><th>Position</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{METRIC_NAME}}</td>
                    <td class="num">{{COMPANY_VALUE}}</td>
                    <td class="num">{{B25}}</td>
                    <td class="num">{{AVG}}</td>
                    <td class="num">{{T25}}</td>
                    <td><span class="position-badge {{POSITION_CLASS}}">{{POSITION}}</span></td>
                </tr>
            </tbody>
        </table>
    </div>
    <!-- Optional: Structural signals interpretation -->
    <div class="card" style="margin-top:1.5rem;">
        <h3 class="card-title">Structural Signals</h3>
        <div class="interpretation-text">{{INTERPRETATION_PARAGRAPH}}</div>
    </div>
</section>
```

**Position badges**: `pos-top` (Top 25%), `pos-avg` (Average), `pos-below` (Below Avg), `pos-bottom` (Bottom 25%), `pos-blank` (BLANK/Dormant)

### Structural Patterns (4 cards)

```html
<section id="patterns">
    <div class="section-header">
        <div class="section-title">Structural Patterns</div>
    </div>
    <div class="pattern-grid">
        <div class="pattern-card">
            <div class="pattern-card-title">{{PATTERN_TITLE}}</div>
            <div class="pattern-card-desc">{{INSIGHT_NOT_OBSERVATION}}</div>
        </div>
        <!-- Repeat for 4 cards -->
    </div>
</section>
```

### Cross-Validation Matrix

```html
<section id="crossval">
    <div class="section-header">
        <div class="section-title">Cross-Validation Matrix</div>
    </div>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr><th>Module</th><th>Order Form</th><th>cACV</th><th>Benchmark</th><th>Verdict</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{MODULE}}</td>
                    <td>{{OF_FINDING}}</td>
                    <td>{{CACV_FINDING}}</td>
                    <td>{{BM_FINDING}}</td>
                    <td><span class="verdict-badge {{VERDICT_CLASS}}">{{VERDICT}}</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</section>
```

**Verdict badges**: `verdict-confirmed` (Confirmed Active), `verdict-partial` (Partial/At Risk), `verdict-dormant` (Confirmed Dormant), `verdict-question` (Needs Investigation)

### Hypothesis Card with VLM Drivers

```html
<section id="hypotheses">
    <div class="section-header">
        <div class="section-title">Hypotheses & VLM Value Drivers</div>
    </div>

    <div class="hypo-card">
        <div class="hypo-header">
            <span class="hypo-priority priority-critical">CRITICAL</span>
            <span class="hypo-status status-confirmed">CONFIRMED</span>
        </div>
        <div class="hypo-title">{{DIAGNOSTIC_TITLE}}</div>
        <div class="hypo-evidence">{{EVIDENCE_PARAGRAPH_CROSS_REFERENCING_ALL_SOURCES}}</div>
        <div class="vlm-drivers">
            <div class="vlm-drivers-label">VLM Value Drivers</div>
            <div class="vlm-driver-list">
                <div class="vlm-driver-item">
                    <span class="vlm-driver-name">{{DRIVER_NAME}}</span>
                    <span class="vlm-driver-meta">KPI: {{KPI}} • {{PL_LINE}} • {{COST_CATEGORY}}</span>
                </div>
            </div>
        </div>
    </div>
    <!-- Repeat for each hypothesis -->
</section>
```

**Priority classes**: `priority-critical`, `priority-high`, `priority-moderate`
**Status classes**: `status-confirmed`, `status-open`

### Timeline & Next Steps

```html
<section id="timeline">
    <div class="section-header">
        <div class="section-title">Timeline & Next Steps</div>
    </div>
    <div class="card">
        <h3 class="card-title">Contract Timeline</h3>
        <div class="timeline-bar">
            <!-- Timeline visualization with key dates -->
        </div>
        <table class="data-table" style="margin-top:1rem;">
            <thead><tr><th>Date</th><th>Event</th><th>Implication</th></tr></thead>
            <tbody>
                <tr><td>{{DATE}}</td><td>{{EVENT}}</td><td>{{IMPLICATION}}</td></tr>
            </tbody>
        </table>
    </div>
    <div class="card" style="margin-top:1.5rem;">
        <h3 class="card-title">Immediate Actions</h3>
        <div class="actions-grid">
            <div class="action-item">
                <div class="action-number">1</div>
                <div class="action-content">
                    <div class="action-title">{{ACTION_TITLE}}</div>
                    <div class="action-desc">{{ACTION_DESCRIPTION}}</div>
                    <div class="action-meta"><strong>Owner:</strong> {{OWNER}} | <strong>By:</strong> {{DEADLINE}} | <strong>Success:</strong> {{SUCCESS_METRIC}}</div>
                </div>
            </div>
        </div>
    </div>
</section>
```

### Footer

```html
<footer class="footer" id="sources">
    <div class="footer-content">
        <div class="footer-title">Data Sources</div>
        <div class="footer-sources">
            <div class="footer-source"><span class="source-tag tag-of">OF</span> {{OF_DESCRIPTION}}</div>
            <div class="footer-source"><span class="source-tag tag-cacv">cACV</span> {{CACV_DESCRIPTION}}</div>
            <div class="footer-source"><span class="source-tag tag-bm">BM</span> {{BM_DESCRIPTION}}</div>
        </div>
        <div class="footer-disclaimer">This document is for internal SAP use only. Data reflects the measurement period indicated. Benchmark comparisons use {{COHORT}} peer group.</div>
    </div>
</footer>
```

---

## Source Tag Classes

```html
<span class="source-tag tag-of">OF</span>      <!-- Blue: Order Form -->
<span class="source-tag tag-cacv">cACV</span>   <!-- Green: Consumption -->
<span class="source-tag tag-bm">BM</span>       <!-- Purple: Benchmark -->
```

---

## PPTX Board Deck Structure (8 Slides)

### Slide 1: Cover
- SAP brand gradient background (deep navy to blue)
- Customer name (large, white)
- Key facts: Term dates, Annual fee, Industry
- "Level 0 Account Health Read" subtitle

### Slide 2: The Diagnostic
- Pattern statement (the 30-second Board sentence)
- 5 KPI boxes in a row (matching the HTML KPI strip)
- Brief interpretation paragraph below

### Slides 3-5: Themes 1-3
Each slide:
- Theme title (business outcome statement)
- Dollar-at-risk callout
- 4-5 evidence bullets with source tags [OF/cACV/BM]
- VLM Value Driver tags at bottom
- Conversation starter in italics

### Slide 6: Engagement Sequence
- 4 touch cards in a 2x2 grid
- Each: timing, title, key action, success criteria

### Slide 7: Renewal Math
- Two-column layout: "Defensible" vs "At Risk"
- Defensible: modules with demonstrated activity + their $ amounts
- At Risk: modules with zero/near-zero activity + their $ amounts
- Total row with amounts
- Timeline callout (months to renewal, credit expiry)

### Slide 8: The Ask
- 4 specific, time-bound actions
- Each with: owner, deadline, success metric
- Frame as "what we need from this room today"
