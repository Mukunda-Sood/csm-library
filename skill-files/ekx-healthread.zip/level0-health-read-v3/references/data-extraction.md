# Data Extraction Guide

## Overview

The Level 0 Health Read requires three data sources to triangulate findings. Each source provides a different lens:

| Source | Tag | What It Tells You | Format |
|--------|-----|-------------------|--------|
| Order Form (OF) | `tag-of` | What they BOUGHT — SKUs, limits, fees, terms, signer | PDF (contract document) |
| cACV File | `tag-cacv` | What they CONSUME — monthly consumption vs. entitlement | CSV/Excel (tabular data) |
| Benchmark Report (BM) | `tag-bm` | What's actually HAPPENING — activity metrics vs. peers | PDF (generated report) |

## Source 1: Order Form (OF)

### What to Extract

| Field | Where to Find | Why It Matters |
|-------|---------------|----------------|
| Case ID | Header or first page | Unique contract identifier |
| Signing Date | Signature block | Establishes contract start |
| Term (Start → End) | "Initial Subscription Term" | Calculates months remaining |
| Annual Fee (total) | Fee table or summary | The $ figure at risk |
| Escalator % | Terms section | Predicts future fee growth |
| Auto-Renew clause | Terms section | Notice period determines urgency |
| Signer name + title | Signature block | Identifies executive stakeholder |
| Credit amount + expiry | Special terms or addendum | Unused credit = leverage/urgency |
| Previous contract reference | Header or preamble | Shows renewal history |
| SKU table | Main body | Maps licensed capabilities to fees |

### SKU Table Fields
For each line item:
- **Cloud Service name** (e.g., "SAP Ariba Buying & Invoicing")
- **Metric type** (Spend, Users, Documents, Invoices, Flat Fee, Transactions)
- **Limitation** (the entitlement cap — e.g., $1.5B, 25 users, 179,000 invoices)
- **Annual Fee** per SKU

### Extraction Tips
- Order Forms are often multi-page PDFs with legal boilerplate. Focus on:
  - The fee/SKU table (usually pages 2-4)
  - The "Special Terms" or "Additional Terms" section (credits, carve-outs)
  - The signature page (signer identity)
- If multiple Order Forms exist (e.g., amendment + original), use the LATEST one as primary but note the original for history
- Watch for "Effective Date" vs. "Signing Date" — they may differ

---

## Source 2: cACV File (Consumption)

### What to Extract

The cACV (consumed Annual Contract Value) file shows monthly billing-level consumption per module. Key columns:

| Column | Description |
|--------|-------------|
| Product/Module Name | The SAP cloud service |
| Line Item ID | Unique billing line (e.g., 8007892) |
| Monthly cACV | What's being consumed (billed) |
| Monthly ACV | What's entitled (contracted) |
| Consumption % | cACV / ACV × 100 |
| Trend (if available) | Month-over-month change |

### Consumption Status Classification

| Consumption % | Status | Badge | Interpretation |
|--------------|--------|-------|----------------|
| 90-100% | Fully Consumed | `dot-active` | Healthy; may need upsizing |
| 50-89% | Partial | `dot-partial` | Active but underutilized |
| 1-49% | Low | `dot-low` | Minimal activity; adoption issue |
| 0% | Dormant | `dot-dormant` | Never activated; waste or oversight |

**Important — Threshold Context**: These cACV thresholds (90/50/1/0) differ from the Entitlements vs. Usage thresholds (80/30/1/0) used in `html-structure.md`. The reason: cACV measures billing-level consumption against a billing cap (hitting 90%+ means the billing ceiling is nearly reached — a commercial signal). Entitlements vs. Usage measures how much of the licensed capacity ceiling is being used (80% is healthy because capacity is intentionally oversized for growth). Apply the correct thresholds to the correct section.

### Extraction Tips
- cACV files are typically CSV or Excel with one row per module per month
- Use the MOST RECENT month available for the dashboard
- If multiple line items exist for the same product (e.g., two B&I lines), note this — it often indicates multiple instances/business units
- Total cACV across all lines should roughly equal the OF annual fee / 12
- Large discrepancies between total cACV and OF fee indicate: (a) recently added SKUs not yet billing, (b) credits applied, or (c) billing timing differences

### Diagnostic Questions from cACV
- Which modules show 0% consumption? (Dormant = never activated)
- Which show >100%? (May be overage or upcoming upsell)
- Are there duplicate line items for the same product? (Multiple instances)
- What's the total monthly burn vs. total monthly entitlement? (Overall health)

---

## Source 3: Benchmark Report (BM)

### What to Extract

Benchmark reports compare the customer's actual activity metrics against a peer cohort. Key sections:

#### Aggregate Metrics
| Metric Category | Example Metrics |
|----------------|-----------------|
| Volume | Total PO count, PO line count, Invoice count, Spend ($) |
| Network | % POs via network, % Invoices via network, % Spend via network |
| Efficiency | R2O cycle time, Invoice approval time, Exception rate |
| Catalog | % PO lines on catalog, Catalog spend |
| Contracts | % PO spend on contracts, Contract count |
| Suppliers | Total supplier count, Suppliers per $M, Spend per supplier |
| Sourcing | Events run, Savings %, Project count |

#### For Each Metric, Extract:
- **Company value** (the customer's actual number)
- **Bottom 25%** (B25 — peer cohort floor)
- **Average** (peer cohort mean)
- **Top 25%** (T25 — peer cohort ceiling)
- **Position** (where the customer falls: Top 25%, Average, Below Average, Bottom 25%)

#### BLANK Values
**CRITICAL**: In benchmark reports, a BLANK field (no data) is DIFFERENT from zero:
- **BLANK** = No activity was recorded during the entire measurement period. The module/feature was never used.
- **Zero** = Activity was attempted but resulted in zero value (e.g., zero savings from completed events).
- **N/A** = Not applicable or not measured for this cohort.

BLANK is the strongest signal of dormancy. Always highlight BLANK metrics explicitly.

### Peer Cohort Context
- Note the cohort definition (industry, region, company size)
- Note the measurement period (e.g., "April 2025 – March 2026")
- The cohort composition affects interpretation:
  - Small cohort (<50 companies): outliers have more impact on averages
  - Industry-specific cohort: more relevant but may have industry biases
  - "All Industries" cohort: less relevant for niche behaviors

### Extraction Tips
- BM reports are typically multi-page PDFs with tables and charts
- Start with the "Summary" or "Executive Overview" page for headline metrics
- Then go detail-by-detail through each module section
- Look for metrics where the customer is BLANK but peers show activity — this is dormancy signal
- Look for metrics where the customer significantly outperforms in one area but underperforms in a related area — this is an asymmetry signal
- Calculate derived metrics the report may not show:
  - Spend per supplier = Total PO spend / Supplier count
  - Suppliers per $M = Supplier count / (Total spend / 1,000,000)
  - Exception rate per PO = Exception invoices / Total POs
  - Network bypass volume = Total POs × (1 - Network PO %)

---

## Cross-Validation Process

After extracting all three sources, build the cross-validation matrix:

### For Each Module/Capability:
1. **OF says**: Is it purchased? At what fee? What entitlement?
2. **cACV says**: Is it being consumed? At what %?
3. **BM says**: Is there measurable activity? At what level vs. peers?

### Verdict Logic:

| OF | cACV | BM | Verdict |
|----|------|----|----|
| Purchased | >80% | Active (metrics populated) | **Confirmed Active** — defensible |
| Purchased | 30-80% | Some activity (below peers) | **Partial** — adoption opportunity |
| Purchased | <30% | Minimal activity | **At Risk** — underutilized |
| Purchased | 0% | BLANK | **Confirmed Dormant** — indefensible without action plan |
| Purchased | Active | BLANK in BM | **Needs Investigation** — billing vs. activity mismatch |
| Not in OF | Shows in cACV | Active in BM | **Bundled/Legacy** — may be included in another SKU |

### Red Flags to Call Out:
- Module is purchased in OF, shows 0% in cACV, AND all BM metrics are BLANK → triple-confirmed dormancy
- Two cACV lines for same product at different % → possible multi-instance architecture
- OF entitlement is much higher than BM actual → massive overprovisioning
- BM shows activity but cACV shows 0% → possible free trial or legacy access not yet monetized

---

## Industry-Specific Extraction Notes

### Consumer Products / CPG
- Supplier base is typically concentrated (fewer suppliers, larger relationships)
- Direct materials (ingredients, packaging) may not flow through Ariba
- Focus on: indirect spend governance, catalog adoption for operational purchasing

### Technology
- High supplier count per $M (many SaaS/services vendors)
- Contract management is critical (SaaS renewals, license compliance)
- Focus on: tail spend management, supplier rationalization, contract visibility

### Manufacturing
- Direct/indirect split is critical context
- Long procurement cycles for capital equipment
- Focus on: supplier quality, delivery performance, invoice automation for high-volume AP

### Financial Services
- Compliance and audit trail matter more than cycle time
- Highly regulated procurement processes
- Focus on: policy compliance, contract governance, risk visibility

### Energy / Utilities
- Long-term contracts (5-10 year) are normal
- Capital project procurement has different dynamics than operational
- Focus on: contract lifecycle management, project-based sourcing, supplier risk

### Healthcare / Life Sciences
- Regulatory compliance dominates
- Approved supplier lists limit sourcing flexibility
- Focus on: compliance automation, qualification workflow, invoice accuracy

---

## File Handling Best Practices

1. **PDFs**: Use text extraction (PyPDF2, pdfplumber, or similar). If the PDF is scanned/image-based, note this as a limitation.
2. **CSVs/Excel**: Parse directly. Watch for:
   - Header rows that may not be row 1
   - Currency formatting (commas, $, negative values in parentheses)
   - Date formats varying between files
3. **Multiple files**: If the customer has multiple OFs (original + amendments), process the latest amendment as primary and the original for history context.
4. **Missing data**: If a source is not provided, note which sections cannot be cross-validated. The dashboard can still be generated with 2 sources, but flag the gap.
