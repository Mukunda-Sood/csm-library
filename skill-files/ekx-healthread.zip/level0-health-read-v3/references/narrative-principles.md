# Narrative Principles: The Top 1% CSM Diagnostic Framework

## Core Philosophy

You are not writing a report. You are writing a **diagnostic narrative** — the kind of document that makes a Board member say "I didn't know that" and an executive ask "what do we do about this?"

The difference between a report and a diagnostic:
- **Report**: "Sourcing utilization is 0%."
- **Diagnostic**: "Your supplier base is 9x more concentrated than peers — each relationship averages $388K. This is the exact profile where fewer sourcing events produce disproportionate ROI. Yet zero events have ever been run. You're paying for competitive leverage tools on a base that would benefit from them more than 90% of customers — and using them less than 100% of customers."

## The Five Diagnostic Patterns

### Pattern 1: The Asymmetry

**What it is**: Two related metrics that tell contradictory stories. The contradiction reveals a structural decision (or non-decision) that explains more than either metric alone.

**How to find it**: Look for metrics that SHOULD correlate but DON'T.
- Invoice Network % vs. PO Network % (suppliers are enabled, but POs are routed around them)
- Catalog line % vs. Total PO lines (the system has a fast path nobody uses)
- Contract spend % vs. Licensed contract users (people log in but nothing is enforced)
- cACV consumption at 100% for one line item vs. 0% for a related one (two instances?)

**How to write it**: State both numbers. Then state what the gap MEANS — not that the gap EXISTS.

**Template**: "[Metric A] shows [value] while [Metric B] shows [contradicting value]. This isn't a [obvious explanation] problem — it's a [structural root cause] that [downstream consequence]."

**Industry-agnostic examples**:
- Manufacturing: "99.8% electronic invoicing but 4.2-day approval cycle — the bottleneck isn't digitization, it's internal routing logic"
- Technology: "85% of spend is under contract, but only 12% of POs reference those contracts — the governance layer exists but isn't enforced at purchase time"
- Energy: "Top 25% for supplier count per $M but Bottom 25% for sourcing events — the fragmented base that most NEEDS competitive leverage gets the least"

---

### Pattern 2: The Proof Point

**What it is**: Evidence within the customer's own data that the solution ALREADY works — for a tiny fraction of activity. This is more powerful than any benchmark because it removes the "but our business is different" objection.

**How to find it**: Look for metrics where a subset dramatically outperforms the whole:
- Catalog R2O vs. Non-catalog R2O (e.g., 0.99 days vs. 5.49 days)
- Network PO compliance vs. non-Network PO outcomes
- Contracted spend vs. non-contracted spend exception rates
- One business unit at 100% consumption vs. another at 56%

**How to write it**: Name the proof point. Quantify the gap. Then ask the scaling question.

**Template**: "When [activity] goes through [the structured path], it takes [fast metric]. When it doesn't, it takes [slow metric]. The system already proves the fix works for [X%] of activity. The question is: why isn't the other [100-X%] using the same path?"

---

### Pattern 3: The Concentration Lever

**What it is**: A structural characteristic of the customer's supplier/transaction base that makes EACH improvement event disproportionately valuable. Concentrated bases benefit more from fewer, deeper interventions.

**How to find it**: Calculate derived metrics:
- Spend per supplier (higher = more leverage per event)
- Suppliers per $M (lower = more concentrated)
- Spend per PO (higher = each efficiency gain is worth more)
- Compare to peer cohort to quantify the multiplier

**How to write it**: Don't just state the concentration. State what it MEANS for the intervention strategy.

**Template**: "With [X] suppliers managing [$Y]M in spend, each relationship averages [$Z]K — [N]% above the peer mean. This isn't a 'cast a wide net' supplier base. It's one where [specific intervention] on the top [N] relationships produces [quantified impact] — and the ROI per event is [multiplier] higher than a typical customer in this cohort."

---

### Pattern 4: The Missing Layer

**What it is**: A licensed capability that shows zero or near-zero activity across ALL data sources. Not "underused" — truly dormant. The significance is not just waste; it's that the ABSENCE of this layer creates downstream problems visible in other metrics.

**How to find it**: Cross-validate:
- OF shows the SKU is purchased (paid for)
- cACV shows 0% or near-0% consumption
- BM shows ALL related metrics as BLANK (not zero — BLANK means no data was even generated)
- Other BM metrics show downstream symptoms (e.g., high exception rates because no contract matching exists)

**How to write it**: Connect the dormant capability to the visible symptoms. The narrative is: "This is WHY that other thing is broken."

**Template**: "[Module] has been licensed since [date] at [$X]/year. Zero [activity type] has ever been recorded — not low activity, zero. The downstream consequence is visible in [related metric]: [symptom]. Without [the missing layer], [dependent process] has no [structural support], and [human workaround] becomes the permanent operating model."

---

### Pattern 5: The Timing Pressure

**What it is**: A contract or credit deadline that creates a natural decision window. This isn't fear-based selling — it's structuring the conversation around an objective timeline that already exists.

**How to find it**: From Order Form:
- Contract end date → months remaining
- Auto-renew clause → notice period required
- Credit amount → expiry date
- Escalator → next price increase date

**How to write it**: Frame as "defensible vs. indefensible" — not "at risk."

**Template**: "The renewal conversation happens in [N] months. Today, [$X] of the [$Y] annual fee is demonstrably producing value (covers [active modules]). The remaining [$Z] funds capabilities showing zero activity. The question isn't whether to renew — it's whether to enter that conversation with [N months] of demonstrated momentum, or with the same utilization profile that makes [$Z] indefensible."

---

### Pattern 6: The Billing Question

**What it is**: A discrepancy between billing-level consumption (cACV) and activity-level measurement (BM). cACV shows near-zero or zero for a module, but Benchmark shows measurable activity flowing through what appears to be that capability — or an adjacent one. This reveals architectural ambiguity: either activity is happening through a different billing line, a bundled entitlement, or a legacy access path that isn't being monetized correctly.

**How to find it**: Cross-validate cACV against BM for each module:
- cACV shows 0% consumption for Module X, but BM shows meaningful activity metrics for Module X's capability
- cACV shows two lines for the same product at dramatically different consumption levels (100% vs. 56%)
- OF shows a SKU that doesn't appear in cACV at all (billing not yet configured)
- BM shows activity in a domain where no OF SKU exists (bundled, legacy, or trial access)

**How to write it**: Name the discrepancy. Identify the possible architectural explanations. Flag that this MUST be resolved internally before customer engagement — presenting conflicting data to a customer destroys credibility.

**Template**: "[Module] shows [X%] consumption at the billing layer (cACV) — yet Benchmark records [measurable activity] in the same domain. This means one of three things: (1) activity is flowing through [adjacent module's billing line], (2) the customer has legacy access from [previous contract] that isn't reflected in current billing, or (3) the BM measurement scope doesn't align with the cACV billing scope. This is a blocking question: do NOT engage the customer on [Module] until the internal billing architecture is understood."

**Industry-agnostic examples**:
- Ariba: "Two B&I billing lines — one at 100%, one at 56%. This typically means two Ariba instances (two business units). The underperforming instance is where the governance gap lives."
- S/4HANA: "cACV shows zero for the Analytics SKU, but BM shows dashboard activity. Check whether Analytics is bundled into the core ERP license for this contract vintage."
- SuccessFactors: "Learning Management shows 0% cACV but BM shows 2,400 course completions. Is Learning bundled into the Employee Central entitlement, or is this a standalone module with misconfigured billing?"
- BTP: "Integration Suite shows 0% consumption but BM shows 150 active integrations. Check whether these run through a pre-existing CPI license that wasn't migrated to the new billing model."

**Critical Note**: Unlike other patterns, The Billing Question creates an **internal gate** — it must be answered BEFORE customer engagement (Touch 1 of the Engagement Sequence). Presenting billing data that contradicts activity data to a customer is a credibility-destroying error.

---

## Writing Quality Standards

### Conversation Starters Must Create Tension

**FAIL test**: If the sentence could be generated by anyone reading a dashboard, it fails.
**PASS test**: The sentence must contain an insight the customer hasn't connected yet.

| Fails | Passes |
|-------|--------|
| "Your sourcing utilization is at 0%" | "Your top 5 suppliers represent ~$200M and every contract was negotiated without competitive leverage tools" |
| "Your R2O cycle time is above average" | "Every purchase — $50 office supply or $200K ingredient — enters the same 5-day approval gauntlet because no fast-path exists" |
| "Your PO Network % is below peers" | "Your suppliers send 100% of invoices through the Network — they're fully enabled. Something on YOUR side is routing 13,000 POs around them" |

### Evidence Must Cross-Reference Sources

Every theme and hypothesis must reference at least 2 of 3 sources. The power is in TRIANGULATION:
- OF tells you what they PAID for
- cACV tells you what they're CONSUMING
- BM tells you what's actually HAPPENING (and what their peers look like)

When all three tell the same story, mark it CONFIRMED.
When they conflict, that conflict IS the insight.

### VLM Drivers Are Not Afterthoughts

VLM drivers are embedded INTO the narrative — not appended as a separate section. Each hypothesis and theme card includes the specific VLM drivers that map to the identified opportunity. This makes the connection between diagnosis and value quantification immediate and visible.

### BLANK Fields Are Diagnostic Gold

In Benchmark reports, BLANK ≠ "data not available." BLANK = "zero activity was recorded during the entire measurement period." This is a STRONGER signal than a low number:
- Low number = they tried, underperformed
- BLANK = they never started

Always call out BLANK fields explicitly. They confirm dormancy at the measurement layer — independent of cACV (which confirms it at the billing layer).

### Industry Context Shapes Interpretation

The same metric means different things in different industries:
- **CPG/Consumer Products**: Concentrated supplier base is NORMAL (few ingredient/packaging suppliers); the diagnostic question is whether competitive leverage is applied to those relationships
- **Technology**: High supplier count per $M is NORMAL (many SaaS/services vendors); the diagnostic question is whether tail spend is managed or ignored
- **Manufacturing**: Direct vs. indirect split is CRITICAL — Ariba typically covers indirect; if spend is mostly direct, utilization % needs reframing
- **Energy**: Long-term contracts are NORMAL; sourcing frequency may be legitimately low — look at contract value and terms instead
- **Financial Services**: Compliance and auditability may matter more than cycle time — frame efficiency gains as risk reduction

Never apply a one-size-fits-all interpretation. Use peer cohort benchmarks to calibrate what "good" looks like for THIS customer's industry.

---

## The 30-Second Board Test

Before writing the Pattern Banner, ask: "If I had 30 seconds with a Board member who knows nothing about procurement technology, what would I say?"

The answer must:
1. Name a specific structural observation (not a metric)
2. Explain why it matters for THIS company (not generically)
3. Quantify what's at stake (dollars, time, or risk)
4. Imply a clear next step without stating it

**Template**: "[N] [entities] are [capability-enabled] for [Activity A] — but [bypassed/unused] for [Activity B]. This isn't a [common assumption] — it's [root cause]. The platform [already does X] but [organizational choice] routes [$Y] [around/away from] it."
