# VLM Value Drivers Reference

## What Are VLM Value Drivers?

VLM (Value Lifecycle Management) Value Drivers map specific SAP platform capabilities to measurable business outcomes. Each driver has:
- **Driver Name**: The specific improvement (e.g., "Reduce invoice error rate")
- **KPI**: The metric that measures success (e.g., "Invoice exception rate %")
- **P&L Line**: Top Line (Revenue) or Bottom Line (Cost)
- **Cost Category**: SG&A, COGS, Revenue, Pre-tax margin, Working Capital

## How to Embed VLM Drivers

VLM drivers are embedded INTO hypothesis cards and theme cards — never in a separate section.

### HTML Format (inside theme cards)
```html
<div class="theme-vlm-list">
    <span class="theme-vlm-tag">Driver Name Here</span>
    <span class="theme-vlm-tag">Another Driver</span>
</div>
```

### HTML Format (inside hypothesis cards)
```html
<div class="vlm-drivers">
    <div class="vlm-drivers-label">VLM Value Drivers</div>
    <div class="vlm-driver-list">
        <div class="vlm-driver-item">
            <span class="vlm-driver-name">Driver Name</span>
            <span class="vlm-driver-meta">KPI: Metric Name • Bottom Line • SG&A</span>
        </div>
        <div class="vlm-driver-item">
            <span class="vlm-driver-name">Another Driver</span>
            <span class="vlm-driver-meta">KPI: Another Metric • Top Line • Revenue</span>
        </div>
    </div>
</div>
```

---

## VLM Driver Catalog by Domain

### Sourcing & Contracts

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Improve sourcing savings on indirect spend | Negotiated savings % on sourced spend | Bottom Line | COGS / SG&A |
| Improve sourcing savings on direct spend | Negotiated savings % on direct materials | Bottom Line | COGS |
| Increase percentage of spend under contract | % of total spend covered by active contracts | Bottom Line | SG&A |
| Increase percentage of PO line items on contract | % of PO lines referencing a contract | Bottom Line | SG&A |
| Improve source to contract FTE productivity | Sourcing events per FTE per quarter | Bottom Line | SG&A |
| Reduce contract cycle time | Days from requisition to executed contract | Bottom Line | SG&A |
| Increase contract compliance | % of spend compliant with contract terms | Bottom Line | COGS / SG&A |
| Reduce maverick buying | % of spend outside contracted channels | Bottom Line | SG&A |

### Procurement Operations (P2O / Buying)

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Reduce Purchase requisition to Purchase Order Cycle Time | Average days from req creation to PO dispatch | Bottom Line | SG&A |
| Improve operational procurement FTE productivity | POs processed per FTE per month | Bottom Line | SG&A |
| Improve user compliance | % of spend through compliant buying channels | Bottom Line | SG&A |
| Increase catalog adoption | % of PO lines placed via catalog | Bottom Line | SG&A |
| Reduce purchase order cost | Avg cost to process one PO (fully loaded) | Bottom Line | SG&A |
| Increase spend under management | % of addressable spend actively managed | Bottom Line | SG&A |
| Comprehensive improvement on indirect spend | Total cost reduction on indirect spend categories | Bottom Line | SG&A |
| Reduce requisition rework rate | % of reqs rejected or returned for correction | Bottom Line | SG&A |

### Accounts Payable / Invoicing

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Reduce invoice error rate | % of invoices with exceptions requiring manual intervention | Bottom Line | SG&A |
| Reduce invoice reprocessing effort | Hours spent resolving invoice exceptions per period | Bottom Line | SG&A |
| Improve accounts payable FTE productivity | Invoices processed per AP FTE per month | Bottom Line | SG&A |
| Reduce Invoice Approval Cycle Time | Average days from invoice receipt to approval | Bottom Line | SG&A |
| Increase electronic invoice adoption | % of invoices received electronically (vs. paper/PDF) | Bottom Line | SG&A |
| Improve early payment discount capture | % of available early pay discounts captured | Bottom Line | Working Capital |
| Reduce duplicate payments | Duplicate payment rate (% or count) | Bottom Line | SG&A |
| Improve invoice-to-PO match rate | % of invoices auto-matched without manual touch | Bottom Line | SG&A |
| Reduce days payable outstanding variance | DPO actual vs. DPO target variance | Bottom Line | Working Capital |

### Supplier Management & Network

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Increase spend on network | % of total spend transacted via network | Bottom Line | SG&A |
| Increase supplier network enablement | % of active suppliers transacting on network | Bottom Line | SG&A |
| Improve supplier risk visibility | % of spend covered by risk monitoring | Bottom Line | COGS / SG&A |
| Reduce supplier onboarding cycle time | Days from request to transactable supplier | Bottom Line | SG&A |
| Improve supplier qualification rate | % of suppliers meeting qualification criteria | Bottom Line | COGS |
| Reduce supply disruption incidents | Count of unplanned supply interruptions per period | Top Line | Revenue |
| Improve supplier performance management | % of suppliers with active scorecards | Bottom Line | COGS |

### Working Capital & Financial

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Optimize working capital through dynamic discounting | Annual discount revenue captured | Bottom Line | Working Capital |
| Improve cash flow forecasting accuracy | Forecast variance % (actual vs. predicted) | Bottom Line | Working Capital |
| Reduce cost of capital through supply chain finance | Weighted avg interest rate on SCF programs | Bottom Line | Pre-tax margin |
| Accelerate revenue recognition | Days from delivery to revenue recognition | Top Line | Revenue |
| Reduce payment error and penalty costs | Annual penalty/late fee costs avoided | Bottom Line | SG&A |

### Services / SAP Ariba Specific

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Improve guided buying adoption | % of reqs created through guided buying | Bottom Line | SG&A |
| Reduce spot buy frequency | % of purchases made without pre-negotiated pricing | Bottom Line | COGS / SG&A |
| Increase use of preferred suppliers | % of spend directed to preferred suppliers | Bottom Line | COGS |
| Improve 3-way match rate | % of invoices passing automated 3-way match | Bottom Line | SG&A |
| Reduce PO-to-invoice discrepancy rate | % of invoices with price/qty variance vs. PO | Bottom Line | SG&A |

### SAP S/4HANA & ERP Modules

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Reduce financial close cycle time | Days to complete monthly/quarterly close | Bottom Line | SG&A |
| Improve inventory turns | Annual inventory turnover ratio | Bottom Line | Working Capital |
| Reduce order-to-cash cycle time | Days from order receipt to cash collection | Top Line | Revenue / Working Capital |
| Improve production planning accuracy | Schedule adherence % | Bottom Line | COGS |
| Reduce unplanned downtime | Hours of unplanned production downtime per period | Top Line | Revenue |
| Improve demand forecast accuracy | Forecast accuracy % (MAPE) | Bottom Line | COGS / Working Capital |
| Reduce logistics cost per unit | Total logistics cost / units shipped | Bottom Line | COGS |
| Improve on-time delivery rate | % of orders delivered on or before promised date | Top Line | Revenue |
| Reduce material waste | Waste % of total material consumed | Bottom Line | COGS |
| Improve warehouse utilization | % of warehouse capacity effectively utilized | Bottom Line | SG&A |

### SAP SuccessFactors / HXM

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Reduce time to hire | Average days from requisition to start date | Bottom Line | SG&A |
| Improve employee retention rate | Annual voluntary turnover % | Bottom Line | SG&A |
| Reduce HR administrative cost per employee | Total HR ops cost / headcount | Bottom Line | SG&A |
| Improve learning completion rate | % of required training completed on time | Bottom Line | SG&A / Risk |
| Increase internal mobility | % of open positions filled internally | Bottom Line | SG&A |
| Improve workforce planning accuracy | Headcount forecast vs. actual variance | Bottom Line | SG&A |
| Reduce payroll error rate | % of pay cycles requiring correction | Bottom Line | SG&A |

### SAP Customer Experience (CX)

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Improve customer conversion rate | % of qualified leads converting to sales | Top Line | Revenue |
| Reduce customer acquisition cost | Total marketing+sales cost per new customer | Bottom Line | SG&A |
| Increase customer lifetime value | Average revenue per customer over relationship | Top Line | Revenue |
| Improve Net Promoter Score | NPS score (quarterly) | Top Line | Revenue |
| Reduce customer churn rate | Annual customer attrition % | Top Line | Revenue |
| Improve marketing campaign ROI | Revenue attributed per marketing dollar spent | Top Line | Revenue |
| Reduce service resolution time | Average hours from ticket to resolution | Bottom Line | SG&A |

### SAP BTP / Technology Platform

| Driver Name | KPI | P&L Line | Cost Category |
|-------------|-----|----------|---------------|
| Reduce integration development time | Days to deploy new integration | Bottom Line | SG&A |
| Improve system availability | % uptime (SLA attainment) | Top Line | Revenue |
| Reduce custom code maintenance cost | Annual cost of custom code maintenance | Bottom Line | SG&A |
| Improve automation rate | % of processes with >80% automation | Bottom Line | SG&A |
| Reduce data latency | Average time from data creation to availability | Bottom Line | SG&A |
| Improve API adoption rate | % of integrations using standard APIs vs. custom | Bottom Line | SG&A |

---

## Selection Guidance

When choosing VLM drivers for a hypothesis or theme:
1. **Relevance**: Only include drivers directly connected to the evidence
2. **Specificity**: Prefer specific drivers ("Reduce Invoice Approval Cycle Time") over generic ones ("Comprehensive improvement")
3. **Limit**: 2-5 drivers per hypothesis card, 3-5 per theme card
4. **Mix**: Include at least one measurable KPI-driven driver and one structural/capability driver
5. **P&L alignment**: Match to the stakeholder. CFO cares about Working Capital. CPO cares about SG&A. CRO cares about Revenue.

## Cross-Product Mapping

For customers with multi-product SAP portfolios, VLM drivers can span modules:
- Ariba + S/4: "Improve 3-way match rate" (requires PO from Ariba + GR from S/4 + Invoice from Network)
- SuccessFactors + BTP: "Reduce time to hire" (requires workflow automation on BTP)
- CX + S/4: "Reduce order-to-cash cycle time" (requires CX order capture + S/4 fulfillment)

Always map the driver to the MODULE being diagnosed, but note cross-module dependencies in the evidence paragraph.
